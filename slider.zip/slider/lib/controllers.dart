import 'package:flutter/material.dart';
import 'package:flutter/material.dart';
import 'package:numberpicker/numberpicker.dart';
import 'package:flutter_picker/flutter_picker.dart';
import 'dart:convert';
import 'utils/shutterTime.dart';
import 'utils/shutterTimeSeconds.dart';
import 'utils/shutterTimeMillis.dart';
import 'bt_connect.dart' as BT;

class Controller extends StatefulWidget {
  @override
  _ControllerState createState() => _ControllerState();
}

class _ControllerState extends State<Controller>
    with AutomaticKeepAliveClientMixin<Controller> {
  @override
  bool get wantKeepAlive => true;

  Widget build(BuildContext context) {
    return Container();
  }
}
