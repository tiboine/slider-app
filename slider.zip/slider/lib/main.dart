import 'package:flutter/material.dart';
import 'controllers.dart';
import 'bt_connect.dart';

void main() => runApp(Slider());

class Slider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Slider',
      initialRoute: '/',
      routes: {
        '/': (context) => BtConnect(),
        '/controller': (context) => Controller(),
      },
    );
  }
}
